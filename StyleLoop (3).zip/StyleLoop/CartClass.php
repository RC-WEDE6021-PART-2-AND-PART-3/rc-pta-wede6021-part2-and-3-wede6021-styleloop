<?php
// CartClass.php
// Shopping cart class containing the required member functions for the POE rubric.
class ShoppingCart {
    public static function ProcessInput() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }
        if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) { $_SESSION['cart'] = []; }
        self::NormaliseCart();
    }

    private static function NormaliseCart() {
        // Converts old cart format [1,1,2] into quantity format [1=>2, 2=>1].
        if (empty($_SESSION['cart'])) { return; }
        $isList = array_keys($_SESSION['cart']) === range(0, count($_SESSION['cart']) - 1);
        if ($isList) {
            $newCart = [];
            foreach ($_SESSION['cart'] as $id) {
                $id = (int)$id;
                if ($id > 0) { $newCart[$id] = ($newCart[$id] ?? 0) + 1; }
            }
            $_SESSION['cart'] = $newCart;
        }
    }

    public static function AddItem($itemID) {
        self::ProcessInput();
        $itemID = (int)$itemID;
        if ($itemID > 0) { $_SESSION['cart'][$itemID] = ($_SESSION['cart'][$itemID] ?? 0) + 1; }
    }

    public static function RemoveItem($itemID) {
        self::ProcessInput();
        $itemID = (int)$itemID;
        if (isset($_SESSION['cart'][$itemID])) { unset($_SESSION['cart'][$itemID]); }
    }

    public static function UpdateQuantity($itemID, $quantity) {
        self::ProcessInput();
        $itemID = (int)$itemID;
        $quantity = (int)$quantity;
        if ($itemID <= 0) { return; }
        if ($quantity <= 0) { unset($_SESSION['cart'][$itemID]); }
        else { $_SESSION['cart'][$itemID] = $quantity; }
    }

    public static function EmptyCart() {
        self::ProcessInput();
        $_SESSION['cart'] = [];
    }

    public static function Login() {
        return isset($_SESSION['UserID']);
    }

    public static function Checkout($conn, $userID) {
        self::ProcessInput();
        if (empty($_SESSION['cart'])) { return false; }

        $referenceNumber = 'SL' . date('YmdHis') . rand(100, 999);
        $grandTotal = 0;

        foreach ($_SESSION['cart'] as $id => $quantity) {
            $id = (int)$id;
            $quantity = max(1, (int)$quantity);

            $stmt = $conn->prepare("SELECT Price, StockQuantity FROM tblClothes WHERE ClothesID=? AND ApprovalStatus='Approved' AND Availability='Available'");
            if (!$stmt) { die('Prepare failed when reading item: ' . $conn->error); }
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();

            if ($row) {
                $availableQty = (int)$row['StockQuantity'];
                $checkoutQty = min($quantity, max(1, $availableQty));
                $unitPrice = (float)$row['Price'];
                $lineTotal = $unitPrice * $checkoutQty;
                $grandTotal += $lineTotal;

                $order = $conn->prepare("INSERT INTO tblOrder (UserID, ClothesID, ReferenceNumber, Quantity, TotalAmount, OrderStatus) VALUES (?, ?, ?, ?, ?, 'Pending Delivery Check')");
                if (!$order) { die('Prepare failed when creating order: ' . $conn->error); }
                $order->bind_param("iisid", $userID, $id, $referenceNumber, $checkoutQty, $lineTotal);
                $order->execute();
                $orderID = $conn->insert_id;

                $line = $conn->prepare("INSERT INTO tblOrderLine (OrderID, ClothesID, Quantity, UnitPrice, LineTotal) VALUES (?, ?, ?, ?, ?)");
                if (!$line) { die('Prepare failed when creating order line: ' . $conn->error); }
                $line->bind_param("iiidd", $orderID, $id, $checkoutQty, $unitPrice, $lineTotal);
                $line->execute();

                $update = $conn->prepare("UPDATE tblClothes SET StockQuantity = GREATEST(StockQuantity - ?, 0), Availability = CASE WHEN GREATEST(StockQuantity - ?, 0) = 0 THEN 'Sold' ELSE 'Available' END WHERE ClothesID=?");
                if (!$update) { die('Prepare failed when updating quantity: ' . $conn->error); }
                $update->bind_param("iii", $checkoutQty, $checkoutQty, $id);
                $update->execute();

                $text = "Checkout reference $referenceNumber: buyer purchased quantity $checkoutQty. Admin must communicate with buyer and seller to confirm delivery and item condition.";
                $msg = $conn->prepare("INSERT INTO tblMessages (UserID, ClothesID, SenderRole, MessageText) VALUES (?, ?, 'Buyer', ?)");
                if (!$msg) { die('Prepare failed when creating message: ' . $conn->error); }
                $msg->bind_param("iis", $userID, $id, $text);
                $msg->execute();
            }
        }

        $visit = $conn->prepare("INSERT INTO tblShoppingVisit (UserID, ReferenceNumber, TotalAmount, VisitStatus) VALUES (?, ?, ?, 'Checkout completed')");
        if (!$visit) { die('Prepare failed when creating shopping visit: ' . $conn->error); }
        $visit->bind_param("isd", $userID, $referenceNumber, $grandTotal);
        $visit->execute();

        self::EmptyCart();
        return $referenceNumber;
    }
}
?>
