<?php
session_start();
include "DBConn.php";
include "CartClass.php";
ShoppingCart::ProcessInput();

if (isset($_GET['id'])) { ShoppingCart::AddItem($_GET['id']); }
if (isset($_GET['remove'])) { ShoppingCart::RemoveItem($_GET['remove']); }
if (isset($_POST['emptycart'])) { ShoppingCart::EmptyCart(); }
if (isset($_POST['updateqty']) && isset($_POST['qty']) && is_array($_POST['qty'])) {
    foreach ($_POST['qty'] as $itemID => $quantity) { ShoppingCart::UpdateQuantity($itemID, $quantity); }
}

$checkoutMessage = "";
$referenceNumber = "";

if (isset($_POST['checkout'])) {
    if (!ShoppingCart::Login()) {
        $checkoutMessage = "Please login or register before checkout.";
    } elseif (empty($_SESSION['cart'])) {
        $checkoutMessage = "Your cart is empty.";
    } else {
        $referenceNumber = ShoppingCart::Checkout($conn, (int)$_SESSION['UserID']);
        $checkoutMessage = "Checkout completed successfully. Reference Number: " . $referenceNumber . ". Admin has been notified to confirm delivery and item condition.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Cart - StyleLoop</title><link rel="stylesheet" href="style.css"></head>
<body>
<?php include "header.php"; ?>
<main class="container">
    <div class="cart-box">
        <h2>Shopping Cart / ShowCart</h2>
        <?php if ($checkoutMessage !== "") { echo "<p class='success'>" . htmlspecialchars($checkoutMessage) . "</p>"; } ?>
        <?php if ($referenceNumber !== "") { echo "<div class='panel-card'><h3>Checkout Reference Number</h3><p><strong>" . htmlspecialchars($referenceNumber) . "</strong></p><p>Your shopping cart has been emptied after checkout.</p></div>"; } ?>

        <?php
        $total = 0;
        if (empty($_SESSION['cart'])) { echo "<p>Your cart is currently empty.</p>"; }
        else { echo "<form method='POST'>"; }

        foreach ($_SESSION['cart'] as $id => $quantity) {
            $id = (int)$id;
            $quantity = max(1, (int)$quantity);
            $stmt = $conn->prepare("SELECT * FROM tblClothes WHERE ClothesID = ?");
            if (!$stmt) { die("SQL Error: " . $conn->error); }
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc();
            if ($item) {
                $lineTotal = $item['Price'] * $quantity;
                $total += $lineTotal;
                echo "<div class='cart-item'>";
                echo "<img src='images/" . htmlspecialchars($item['ImageName']) . "' alt='item'>";
                echo "<div><strong>" . htmlspecialchars($item['BrandName']) . " - " . htmlspecialchars($item['ItemName']) . "</strong><br>Unit Price: R" . number_format($item['Price'], 0) . "<br>Available: " . (int)$item['StockQuantity'] . "</div>";
                echo "<div><label>Qty</label><input type='number' min='1' max='" . (int)$item['StockQuantity'] . "' name='qty[" . $item['ClothesID'] . "]' value='" . $quantity . "'></div>";
                echo "<strong>R" . number_format($lineTotal, 0) . "</strong>";
                echo "<a href='cart.php?remove=" . $item['ClothesID'] . "'>Remove</a>";
                echo "</div>";
            }
        }
        if (!empty($_SESSION['cart'])) {
            echo "<div class='cart-total'>Total: R" . number_format($total, 0) . "</div>";
            echo "<div style='text-align:right; margin-top:15px;'>";
            echo "<button style='width:auto;' name='updateqty' value='1' type='submit'>Update Cart</button> ";
            echo "<button style='width:auto;' name='checkout' value='1' type='submit'>Checkout</button> ";
            echo "<button style='width:auto;' name='emptycart' value='1' type='submit'>Empty Cart</button> ";
            echo "<a class='btn' href='shop.php'>Continue Shopping</a>";
            echo "</div></form>";
        } else {
            echo "<a class='btn' href='shop.php'>Continue Shopping</a>";
        }
        ?>

        <?php if (!empty($_SESSION['cart']) && !isset($_SESSION['UserID'])) { ?>
            <p class="error">You must login or register before checkout.</p>
            <a class="btn" href="login.php">Login</a>
            <a class="btn" href="register.php">Register</a>
        <?php } ?>
    </div>
</main>
</body>
</html>
