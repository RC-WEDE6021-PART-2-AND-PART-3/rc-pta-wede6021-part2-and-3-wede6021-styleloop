<?php
// addToCart.php
// Adds a selected clothing item to the session cart and increases quantity if the same item is added again.
include "CartClass.php";
ShoppingCart::ProcessInput();

if (isset($_GET['id'])) {
    ShoppingCart::AddItem($_GET['id']);
}

$returnPage = $_GET['return'] ?? 'itemsTable.php';
$allowedPages = ['itemsTable.php', 'shop.php', 'productDetails.php', 'cart.php'];
if (!in_array($returnPage, $allowedPages)) { $returnPage = 'itemsTable.php'; }
header('Location: ' . $returnPage . '?added=1');
exit();
?>
